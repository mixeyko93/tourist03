import { useState } from 'react';
import { LoginCalm } from './components/LoginCalm';
import { LoginVibrant } from './components/LoginVibrant';
import { motion, AnimatePresence } from 'framer-motion';

export default function App() {
  const [variant, setVariant] = useState<'calm' | 'vibrant'>('calm');

  return (
    <div className="relative">
      {/* Variant switcher */}
      <motion.div 
        className="fixed top-8 right-8 z-50 flex gap-2 bg-black/40 backdrop-blur-md border border-white/10 rounded-lg p-1"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <button
          onClick={() => setVariant('calm')}
          className={`px-4 py-2 rounded-md text-sm transition-all duration-300 relative overflow-hidden ${
            variant === 'calm'
              ? 'text-white font-medium'
              : 'text-white/60 hover:text-white/90 font-normal'
          }`}
        >
          {variant === 'calm' && (
            <motion.div
              layoutId="activeTab"
              className="absolute inset-0 bg-blue-500 shadow-lg shadow-blue-500/30 rounded-md"
              transition={{ type: "spring", bounce: 0.15, duration: 0.6 }}
            />
          )}
          <span className="relative z-10">Спокойная</span>
        </button>
        <button
          onClick={() => setVariant('vibrant')}
          className={`px-4 py-2 rounded-md text-sm transition-all duration-300 relative overflow-hidden ${
            variant === 'vibrant'
              ? 'text-white font-medium'
              : 'text-white/60 hover:text-white/90 font-normal'
          }`}
        >
          {variant === 'vibrant' && (
            <motion.div
              layoutId="activeTab"
              className="absolute inset-0 bg-gradient-to-r from-purple-500 to-pink-500 shadow-lg shadow-purple-500/30 rounded-md"
              transition={{ type: "spring", bounce: 0.15, duration: 0.6 }}
            />
          )}
          <span className="relative z-10">Яркая</span>
        </button>
      </motion.div>

      {/* Render selected variant with smooth transition */}
      <div className="relative w-full h-screen">
        <AnimatePresence initial={false}>
          {variant === 'calm' && (
            <motion.div
              key="calm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ 
                duration: 0.6,
                ease: "easeInOut",
                opacity: { duration: 0.6 }
              }}
              className="absolute inset-0"
              style={{ zIndex: variant === 'calm' ? 2 : 1 }}
            >
              <LoginCalm />
            </motion.div>
          )}
          {variant === 'vibrant' && (
            <motion.div
              key="vibrant"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ 
                duration: 0.6,
                ease: "easeInOut",
                opacity: { duration: 0.6 }
              }}
              className="absolute inset-0"
              style={{ zIndex: variant === 'vibrant' ? 2 : 1 }}
            >
              <LoginVibrant />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}