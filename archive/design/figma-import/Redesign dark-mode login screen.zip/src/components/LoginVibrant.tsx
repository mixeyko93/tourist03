import React, { useState } from 'react';
import { Input } from './Input';
import { Button } from './Button';

export function LoginVibrant() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Reset errors
    setErrors({});
    
    // Simple validation
    const newErrors: { email?: string; password?: string } = {};
    
    if (!email) {
      newErrors.email = 'Введите email';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Некорректный email';
    }
    
    if (!password) {
      newErrors.password = 'Введите пароль';
    } else if (password.length < 6) {
      newErrors.password = 'Минимум 6 символов';
    }
    
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }
    
    // Simulate login
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      console.log('Login:', { email, password });
    }, 2000);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center relative overflow-hidden bg-gradient-to-br from-slate-950 via-purple-950/30 to-slate-950" style={{ isolation: 'isolate' }}>
      {/* Multiple vibrant glows */}
      <div className="absolute top-1/3 left-1/4 w-[500px] h-[500px] bg-purple-600/15 rounded-full blur-[140px]"></div>
      <div className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] bg-pink-500/10 rounded-full blur-[120px]"></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/5 rounded-full blur-[160px]"></div>
      
      {/* Login card */}
      <div className="relative z-10 w-full max-w-md mx-auto px-4">
        {/* Glass card with vibrant glow */}
        <div className="relative">
          {/* Enhanced card glow effect */}
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-pink-500/10 to-purple-500/20 rounded-2xl blur-2xl"></div>
          <div className="absolute inset-0 bg-gradient-to-tl from-purple-600/10 via-transparent to-pink-500/10 rounded-2xl blur-xl"></div>
          
          {/* Main card */}
          <div className="relative backdrop-blur-2xl bg-white/[0.04] border border-purple-500/20 rounded-2xl p-8 shadow-[0_8px_32px_rgba(168,85,247,0.15)]">
            {/* Title with gradient */}
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-200 via-white to-pink-200 bg-clip-text text-transparent mb-2 tracking-tight">
                Турист ⛺️
              </h1>
              <p className="text-sm text-white/90">
                CRM для управляющих базами отдыха
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="email"
                placeholder="Email"
                icon="email"
                variant="vibrant"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                error={errors.email}
              />

              <Input
                type="password"
                placeholder="Пароль"
                icon="password"
                variant="vibrant"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                error={errors.password}
              />

              <div className="pt-2">
                <Button variant="vibrant" loading={loading} type="submit">
                  Войти
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}