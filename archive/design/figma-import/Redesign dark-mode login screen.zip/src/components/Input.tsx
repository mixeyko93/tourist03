import React, { useState, InputHTMLAttributes } from 'react';
import { Mail, Lock, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

type IconType = 'email' | 'password';

interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'className'> {
  label?: string;
  error?: string;
  icon?: IconType;
  variant?: 'calm' | 'vibrant';
}

export function Input({ 
  label, 
  error, 
  icon, 
  variant = 'calm',
  type = 'text',
  ...props 
}: InputProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const IconComponent = icon === 'email' ? Mail : icon === 'password' ? Lock : null;

  const baseStyles = "w-full h-12 px-4 pl-12 rounded-lg transition-all duration-200 outline-none";
  
  const calmStyles = {
    default: "bg-white/5 border border-white/10 text-white placeholder:text-white/40",
    hover: isHovered && !isFocused && !error ? "border-white/20 bg-white/[0.07]" : "",
    focus: isFocused && !error ? "border-blue-500/50 bg-white/[0.08] ring-4 ring-blue-500/10" : "",
    error: error ? "border-red-500/50 bg-red-500/5 ring-4 ring-red-500/10" : ""
  };

  const vibrantStyles = {
    default: "bg-white/[0.03] border border-purple-500/20 text-white placeholder:text-white/60",
    hover: isHovered && !isFocused && !error ? "border-purple-400/40 bg-white/[0.06] shadow-[0_0_20px_rgba(168,85,247,0.15)]" : "",
    focus: isFocused && !error ? "border-purple-500/60 bg-white/[0.08] ring-4 ring-purple-500/20 shadow-[0_0_30px_rgba(168,85,247,0.25)]" : "",
    error: error ? "border-red-500/60 bg-red-500/5 ring-4 ring-red-500/15 shadow-[0_0_20px_rgba(239,68,68,0.2)]" : ""
  };

  const styles = variant === 'calm' ? calmStyles : vibrantStyles;
  const iconColor = variant === 'calm' 
    ? (error ? "text-red-400" : isFocused ? "text-blue-400" : "text-white/30")
    : (error ? "text-red-600" : isFocused ? "text-purple-300" : "text-purple-200/50");
  
  const errorTextColor = variant === 'calm' ? "text-red-400" : "text-red-700";

  return (
    <div className="w-full">
      {label && (
        <label className="block mb-2 text-sm text-white/70">
          {label}
        </label>
      )}
      <div className="relative">
        {IconComponent && (
          <div className={`absolute left-4 top-1/2 -translate-y-1/2 transition-colors duration-200 ${iconColor}`}>
            <IconComponent size={18} strokeWidth={2} />
          </div>
        )}
        <input
          type={type}
          className={`${baseStyles} ${styles.default} ${styles.hover} ${styles.focus} ${styles.error}`}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          {...props}
        />
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className={`absolute right-4 top-1/2 -translate-y-1/2 ${errorTextColor}`}
            >
              <AlertCircle size={18} strokeWidth={2} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
      <AnimatePresence>
        {error && (
          <motion.p
            initial={{ opacity: 0, y: -8, height: 0 }}
            animate={{ opacity: 1, y: 0, height: 'auto' }}
            exit={{ opacity: 0, y: -8, height: 0 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
            className="mt-2 text-sm flex items-center gap-1 overflow-hidden"
          >
            <span className={errorTextColor}>{error}</span>
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}