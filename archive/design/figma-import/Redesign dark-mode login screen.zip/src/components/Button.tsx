import React, { ButtonHTMLAttributes, useState } from 'react';
import { Loader2 } from 'lucide-react';

interface ButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className'> {
  variant?: 'calm' | 'vibrant';
  loading?: boolean;
  children: React.ReactNode;
}

export function Button({ 
  variant = 'calm', 
  loading = false, 
  disabled,
  children, 
  ...props 
}: ButtonProps) {
  const [isPressed, setIsPressed] = useState(false);

  const isDisabled = disabled || loading;

  const baseStyles = "w-full h-12 rounded-lg transition-all duration-200 font-medium relative overflow-hidden";

  const calmStyles = {
    default: "bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-500/25",
    hover: !isDisabled ? "hover:shadow-xl hover:shadow-blue-500/40 hover:scale-[1.02]" : "",
    active: isPressed && !isDisabled ? "scale-[0.98]" : "",
    disabled: isDisabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer",
    glow: !isDisabled ? "before:absolute before:inset-0 before:bg-gradient-to-r before:from-blue-400/0 before:via-white/20 before:to-blue-400/0 before:translate-x-[-200%] hover:before:translate-x-[200%] before:transition-transform before:duration-700" : ""
  };

  const vibrantStyles = {
    default: "bg-gradient-to-r from-purple-600 via-purple-500 to-pink-500 text-white shadow-[0_0_30px_rgba(168,85,247,0.4)]",
    hover: !isDisabled ? "hover:shadow-[0_0_50px_rgba(168,85,247,0.6)] hover:scale-[1.02]" : "",
    active: isPressed && !isDisabled ? "scale-[0.98] shadow-[0_0_40px_rgba(168,85,247,0.5)]" : "",
    disabled: isDisabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer",
    glow: !isDisabled ? "before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/30 before:to-transparent before:translate-x-[-200%] hover:before:translate-x-[200%] before:transition-transform before:duration-700" : ""
  };

  const styles = variant === 'calm' ? calmStyles : vibrantStyles;

  return (
    <button
      className={`${baseStyles} ${styles.default} ${styles.hover} ${styles.active} ${styles.disabled} ${styles.glow}`}
      disabled={isDisabled}
      onMouseDown={() => setIsPressed(true)}
      onMouseUp={() => setIsPressed(false)}
      onMouseLeave={() => setIsPressed(false)}
      {...props}
    >
      <span className="relative z-10 flex items-center justify-center gap-2">
        {loading && (
          <Loader2 className="animate-spin" size={18} strokeWidth={2.5} />
        )}
        {children}
      </span>
    </button>
  );
}
