
  # Redesign dark-mode login screen

  This is a code bundle for Redesign dark-mode login screen. The original project is available at https://www.figma.com/design/J0yINiq2nmmXoAlTpiVyHs/Redesign-dark-mode-login-screen.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  